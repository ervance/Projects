package com.example.eric.magic8ball;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MagicEightBallDisplayController extends Activity {

    //Eight Ball
    final MagicEightBall magicEightBall = new MagicEightBall();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_display);

        final TextView answerTextView = (TextView) findViewById(R.id.answer);
        final Button randomAnswerButton = (Button) findViewById(R.id.generate_answer);

        //If button is clicked randomly generate answer from eight ball class and display
        randomAnswerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String randomAnswer;
                randomAnswer = magicEightBall.generateRandomAnswer();
                answerTextView.setText(randomAnswer);
            }
        });
    }
    
}

package com.example.eric.magic8ball;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MagicEightBallDisplayController extends Activity{


    final MagicEightBall eightBall = new MagicEightBall();//Eight Ball object
    private TextView answerTextView;
    /******Sensor objects********/
    private Sensor accelSensor;
    private SensorManager sensorManager;
    private SensorEventListener listener;
    /***Variables to keep track of sensor data so it does not constantly flip****/
    private float prevZAxis = 0; //Keep track of previous axis to improve flipping
    private boolean changeText = false;
    //Holds the random clairvoyance answer to change textView
    private String randomAnswer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_display);

        //Default starting text
        final String DEFAULT_INSTRUCTION_TEXT = "Ask a question and tilt face down";

        //textView
        answerTextView = (TextView) findViewById(R.id.answer);

        //Set text to previous answer on screen flip
        if (savedInstanceState != null) {
            Log.d("SAVEDINSTANCE", "Saved Instance is not Null");
            randomAnswer = savedInstanceState.getString("ANSWER");
            answerTextView.setText(randomAnswer);
        }
        //No previous answer, set it to the defualt
        else {
            randomAnswer = DEFAULT_INSTRUCTION_TEXT;
            answerTextView.setText(DEFAULT_INSTRUCTION_TEXT);
        }

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                float xAxis, yAxis, zAxis;
//              xAxis = sensorEvent.values[0];
//              yAxis = sensorEvent.values[1];
                zAxis = sensorEvent.values[2];
                //debugging data for axis changes
//              Log.d("AXIS_DATA", "xAxis = " + xAxis);
//              Log.d("AXIS_DATA", "yAxis = " + yAxis);
//                Log.d("AXIS_DATA", "zAxis = " + zAxis);
                /*
                capture the motion of flipping
                zAxis will be negative when face down
                if the face is flipped up it will be positive
                if the phone was face down then flipped face up change the text
                */
                if (zAxis >= 0 && prevZAxis <= -3) {
                    changeText = true; //Phone is face down
                    prevZAxis = zAxis;
                }
                else {
                    prevZAxis = zAxis;
                }
                //Phone was face down, change the text
                if (changeText) {
//                    Log.d("PREVZAXIS", "Previous zAxis = " + prevZAxis);
                    setRandomText();
                    changeText = false;
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };

        sensorManager = (SensorManager) this.getSystemService(this.SENSOR_SERVICE);
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(listener, accelSensor, SensorManager.SENSOR_DELAY_NORMAL);



    }



    //generate random text for eightball
    private void setRandomText(){
        randomAnswer = eightBall.generateRandomAnswer();
        answerTextView.setText(randomAnswer);
    }

    @Override
    protected void onResume() {//register listener when activity resumes
        super.onResume();
        sensorManager.registerListener(listener, accelSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override
    protected void onPause() {//unregister listener to save battery when activity pauses
        super.onPause();
        sensorManager.unregisterListener(listener, accelSensor);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){//Keep text when app rotates
        super.onSaveInstanceState(outState);
        outState.putString("ANSWER", randomAnswer);
    }
}
